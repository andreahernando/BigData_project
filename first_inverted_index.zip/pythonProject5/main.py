from inverted_index_of import inverted_index_of
from time import *

if __name__ == '__main__':
    start = time()

    x = inverted_index_of()
    print(x)
    end = time()
    print(end-start)





