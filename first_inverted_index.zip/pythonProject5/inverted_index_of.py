from nltk.corpus import stopwords


def inverted_index_of():
    file = open('C:/Users/andre/Desktop/Andre Uni/Tercero/BD/prueba2.txt')
    read = file.read()
    file.seek(0)

    line = 1
    for word in read:
        if word == '\n':
            line += 1

    array = []
    for i in range(line):
        array.append(file.readline())

    punc = '''!()-[]{};:'"\, <>./?@#$%=^&*_~'''
    stop = set(stopwords.words('english'))
    for ele in read:
        if ele in punc:
            read = read.replace(ele, " ")

    read = read.lower()
    words = []
    list_words = read.split()

    for i in list_words:
        if i not in words:
            if i not in stop:
                words.append(i)


    word_line = {}

    for i in range(line):
        check = array[i].lower()
        for item in words:

            if item in check:
                if item not in word_line:
                    word_line[item] = []

                if item in word_line:
                    word_line[item].append(i + 1)

    return word_line
